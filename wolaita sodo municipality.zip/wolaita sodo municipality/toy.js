
	var index = 0;
	var images = document.querySelectorAll('.slideshow img');
	var totalImages = images.length;
	function showImage() {
		images[index].style.display = 'none';
		index = (index + 1) % totalImages;
		images[index].style.display = 'block';
	}
	setInterval(showImage, 1000); // Change image every 1 seconds
