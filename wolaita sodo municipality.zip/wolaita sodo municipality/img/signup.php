<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Process signup form data
        $username = $_POST["username"];
        $password = $_POST["password"];
        $role = $_POST["role"];

        // You can perform validation and other necessary operations here

        // After processing, you can redirect the user to another page
        header("Location: success.php");
        exit(); // Ensure that subsequent code is not executed
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <h2>Sign Up</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br><br>

        <label for="role">Select User Type:</label>
        <select name="role" id="role">
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="employee">Employee</option>
        </select><br><br>

        <button type="submit">Sign Up</button>
    </form>
</body>
</html>
