<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head><meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Enforcement | Wolaita Sodo City Municipality</title>
	<meta name="author" content="Narayan">
	<link rel="stylesheet" type="text/css" href="inf.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
	<link rel="favicon icon" href="images/favicon.png">
	<script src="https://kit.fontawesome.com/7ae7324af5.js" crossorigin="anonymous"></script>
</head>
<body>

<!-- navbar start -->
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">


		<div class="navbar-header" >
			<a class="navbar-brand" href="#"><img src="Flag_of_Southern_Ethiopia.png" alt="" style="height: 40px; width: 80px; margin-top: -10px; margin-left: -10px"></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav">
			<li class="active"><a href="infrastructure.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			<li ><a href="#">Gallery</a></li>
            <li ><a href="inf_service.php">Service</a></li>
		</ul>
		<img src="Ethiopia_240-animated-flag-gifs (1).gif" alt="Image 1" style="width: 90px; height: 40px; margin-top: 8px;">
	        <ul class="nav navbar-nav navbar-right">
 			<li><a href="con_login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		</ul>
	</div>
	</div>
	</nav>
<!-- navbar end -->


                   <!-- services to book -->
<div class="container-fluid">

  <div class="text-center">
  <div class="panel panel-primary">
  <br><br><br>
  <div class="panel-heading">
    <h2>Enforcement Sector</h2>
    <h4>Enforcement Sectors Include Four Main Services</h4>
    </div>
   </div>
  </div>
  <div>
    <div >
    <a href="inf_inf.php">
      <div class="panel panel-primary text-center">
        <div class="panel-heading">
          <h1>Infrastructure<br></h1>
        </div>
      </div></a>
    </div>
    <div class="-sm-4">
    <a href="inf_cle.php">
      <div class="panel panel-primary text-center">
        <div class="panel-heading">
          <h1>Cleaning<br>Beauty</h1>
        </div>
        </div></a>
    </div>
   <div class="-sm-4"> <a href="#">
      <div class="panel panel-primary text-center">
        <div class="panel-heading">
          <h1>Community<br>Partcipation</h1>
        </div>
        </div></a>
    </div>
    <div class="">  <a href="inf_sla.php">
      <div class="panel panel-primary text-center">
        <div class="panel-heading">
          <h1>Slaughterhouse<br></h1>
        </div>
        </div> </a>
    </div>
  </div>
</div>
<!-- service end -->

<!-- footer -->
<div class="container-fluid jumbotron" style="background-color: #066; color: white;">
	<div class="row">
		<div class="col-sm-4">
			<h2><u>Contact us:</u></h2>
			<h3>Wolaita Sodo City Municipality</h3>
			<p><span class="glyphicon glyphicon-map-marker"></span>Wolaita, Sodo</p>
            <p><span class="glyphicon glyphicon-phone"></span> 046-6924118</p>
           <p><span class="glyphicon glyphicon-envelope"></span> wolaitaSodoMun@gmail.com</p>
		   <div class="mann">
		        <a href="https://www.facebook.com/photo/?fbid=231803562467254&set=a.231803545800589&__tn__=%3C"><i class="fa-brands fa-facebook fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://t.me/sodocomunication"><i class="fa-brands fa-telegram fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-youtube fa-beat-fade fa-2x" style="color: #f00000;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-linkedin fa-beat-fade fa-2x" style="color: #22009e;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://sodo.gov.et/"><i class="fa-brands fa-google fa-beat-fade fa-2x" style="color: #2c0d49;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
            </div>
		</div>
		<div class="col-sm-4">
			<h2><u>Google Map</u></h2>
			<iframe src="https://www.google.com.qa/maps/d/u/0/embed?mid=1FnoxM9FTZVM35SQ867ncVnQBt6bpcBk&ehbc=2E312F" width="300" height="200"></iframe>		</div>
		<div class="col-sm-4">
			<h2><u>Social Media</u><BR>Facebook</h2>
		<div class="fb-page" data-href="https://www.facebook.com/profile.php?id=100067551376751" data-tabs="timeline" data-width="200" data-height="200" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/profile.php?id=100067551376751" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/profile.php?id=100067551376751">Wolaita Sodo City Chief Administration</a></blockquote></div>
		<br>
		<div id="fb-root"></div>
			<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v20.0&appId=356868713743682" nonce="3GNSfzN0"></script>				<h2>Telegram</h2>

			<script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-post="sodocomunication/2" data-width="30%" data-userpic="true" data-color="F646A4"></script>
		</div>
    </div>
	<footer class="container-fluid bg-4 text-center">
  <p>All right reserved <a href="https://github.com/tarecp/tarecp">@ WSCM</a></p>
</footer>
</div>
<!-- footer end -->
</body>
</html>
