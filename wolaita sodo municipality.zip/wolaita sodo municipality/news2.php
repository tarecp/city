service.html<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home | Wolaita Sodo City Municipality</title>
	<meta name="author" content="Narayan">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
	<link rel="favicon icon" href="images/favicon.png">
	<script src="https://kit.fontawesome.com/7ae7324af5.js" crossorigin="anonymous"></script>
</head>
<body>
<!-- navbar start -->
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>

		<div class="navbar-header" >
			<a class="navbar-brand" href="#"><img src="Flag_of_Southern_Ethiopia.png" alt="" style="height: 40px; width: 80px; margin-top: -10px; margin-left: -10px"></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav">
			<li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			<li ><a href="about.php">About us</a></li>
			<li ><a href="gallery.php">Gallery</a></li>
			<li><a href="news.php">News and Articles</a></li>
			<li><a href="booking.php">E-Serivces</a></li>
			<li><a href="service.php">Serivces</a></li>
		<li><a href="contact.php">Contact us</a></li>
		</ul>

	<div>
    <div class="panel panel-primary">
					<div class="panel panel-heading">
					<h2>Yestrday News</h2>
					</div>
					<div class="panel panel-body">
					Deputy Chief of the Southern Nations, Nationalities and People's Region (SNNPR), Erstu Yirda, and other senior officials of 
					the state and Wolayita Zone visited an individual field in Abaya Bisare Woreda of Wolayita Zone.

                    In a short period of time, the individual has been successful in the investment sector. Investor, Dagne Daba, 
					said over 450 hectares of land has been covered with crops in one month. Mr Dagne added: He also said that he is 
					preparing to plant orange and banana seedlings. According to Dagne Masho, efforts are underway to export the produce 
					to Adingo / Boloke and Masho seeds during the harvest season.
                    He said more than 250 temporary and permanent workers have been created from the area. In less than a month, the 
					effort to cover more than 450 hectares of land with seeds is commendable and exemplary, said Deputy Chief of the 
					Southern Nations, Nationalities and People's Region, Erstu Yirda. He said other activities should be considered as 
					his best experience as it will be of great benefit to the country's development.
                    He said if the individuals who are taking over the land to invest in the land do not work, it should be handed over 
					to the leaving investors and the government will continue to strengthen its control in this regard. He said that this 
					is a great start and should be encouraged and that we should do our best to achieve results even if there are problems.
					</div>
				</div>
    </div>
	</div>
	</div>	
	</nav>
<!-- navbar end -->
</body>
</html>