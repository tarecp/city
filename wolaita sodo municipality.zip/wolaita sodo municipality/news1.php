service.html<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home | Wolaita Sodo City Municipality</title>
	<meta name="author" content="Narayan">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
	<link rel="favicon icon" href="images/favicon.png">
	<script src="https://kit.fontawesome.com/7ae7324af5.js" crossorigin="anonymous"></script>
</head>
<body>
<!-- navbar start -->
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>

		<div class="navbar-header" >
			<a class="navbar-brand" href="#"><img src="Flag_of_Southern_Ethiopia.png" alt="" style="height: 40px; width: 80px; margin-top: -10px; margin-left: -10px"></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav">
			<li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			<li ><a href="about.php">About us</a></li>
			<li ><a href="gallery.php">Gallery</a></li>
			<li><a href="news.php">News and Articles</a></li>
			<li><a href="booking.php">E-Serivces</a></li>
			<li><a href="service.php">Serivces</a></li>
		<li><a href="contact.php">Contact us</a></li>
		</ul>

	<div>
    <div class="panel panel-primary">
		<div class="panel panel-heading">
			<h2>Latest News</h2>
		</div>
		<div class="panel panel-body">
					According to Aisha Mohammed, Minister of Urban Development and Construction of the Federal Democratic Republic of Ethiopia (FDRE), 
					Ethiopia's urbanization rate has reached 5.4 percent.

                    He said the rapid urbanization of the Southern Nations, Nationalities and People's Region (SNNPR) is unstoppable due to 
                    the migration from rural to urban areas.
                    According to Aisha, it is important to build strong community participation and implement regulations and 
                    legal frameworks to make cities clean, healthy and attractive. "There is a city with a leader who understands his 
                    responsibilities and works properly," said Erstu Yirda, Deputy Chief of the Southern Nations, Nationalities and People's 
                    Region.
		</div>
    </div>
    </div>
	</div>
	</div>	
	</nav>
<!-- navbar end -->
</body>
</html>