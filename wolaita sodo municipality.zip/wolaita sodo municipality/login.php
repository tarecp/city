<?php 
   session_start();
   if (!isset($_SESSION['username']) && !isset($_SESSION['id'])) {   ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>wolaita sodo municipality login-</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="m.jpg" style="background-size: 100% 100%;">

<!-- navbar start -->
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>

		<div class="navbar-header" >
			<a class="navbar-brand" href="#"><img src="Flag_of_Southern_Ethiopia.png" alt="" style="height: 40px; width: 80px; margin-top: -10px; margin-left: -10px"></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav">
			<li class="active"><a href="constraction.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			<li ><a href="con_about.php">About us</a></li>
			<li ><a href="con_gallery.php">Gallery</a></li>
			<li><a href="con_service.php">Serivces</a></li>
		</ul>
		<img src="Ethiopia_240-animated-flag-gifs (1).gif" alt="Image 1" style="width: 90px; height: 40px; margin-top: 8px;">
	        <ul class="nav navbar-nav navbar-right">
			<li><a href="constraction.php"><span class="glyphicon glyphicon-log-in"></span>Back </a></li>
		</ul>
	</div>
	</div>	
	</nav>
<!-- navbar end -->



      <div class="container d-flex justify-content-center align-items-center"
      style="min-height: 100vh">
      	<form class="border shadow p-3 rounded"
      	      action="php/check-login.php" 
      	      method="post" 
      	      style="width: 450px; background: skyblue; padding: 30px; margin-top: 22%; margin-left: 25%;">
      	      <h1 class="text-center p-3">LOGIN</h1>
      	      <?php if (isset($_GET['error'])) { ?>
      	      <div class="alert alert-danger" role="alert">
				  <?=$_GET['error']?>
			  </div>
			  <?php } ?>
		  <div class="mb-3">
		    <label for="username" 
		           class="form-label">User name</label>
		    <input type="text" 
		           class="form-control" 
		           name="username" 
		           id="username">
		  </div>
		  <div class="mb-3">
		    <label for="password" 
		           class="form-label">Password</label>
		    <input type="password" 
		           name="password" 
		           class="form-control" 
		           id="password">
		  </div>
		  <div class="mb-1">
		    <label class="form-label">Select User Type:</label>
		  </div>
		  <select class="form-control"
		          name="role" 
		          aria-label="Default select example">
			  <option selected value="user">User</option>
			  <option value="admin">Admin</option>
			  <option  value="employee">Employee</option>
		  </select>
		 <br>
		  <button type="submit" 
		          class="btn btn-primary" style="margin-left: 35%">LOGIN</button>
		</form>
      </div>
	  <!-- footer -->
<div class="container-fluid jumbotron" style="background-color: #066; color: white;">
	<div class="row">
		<div class="col-sm-4">
			<h2><u>Contact us:</u></h2>
			<h3>Wolaita Sodo City Municipality</h3>
			<p><span class="glyphicon glyphicon-map-marker"></span>Wolaita, Sodo</p>
            <p><span class="glyphicon glyphicon-phone"></span> 046-6924118</p>
           <p><span class="glyphicon glyphicon-envelope"></span> wolaitaSodoMun@gmail.com</p>
		   <div class="mann">
		        <a href="https://www.facebook.com/photo/?fbid=231803562467254&set=a.231803545800589&__tn__=%3C"><i class="fa-brands fa-facebook fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://t.me/sodocomunication"><i class="fa-brands fa-telegram fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-youtube fa-beat-fade fa-2x" style="color: #f00000;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-linkedin fa-beat-fade fa-2x" style="color: #22009e;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://sodo.gov.et/"><i class="fa-brands fa-google fa-beat-fade fa-2x" style="color: #2c0d49;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
            </div>
		</div>
		<div class="col-sm-4">
			<h2><u>Google Map</u></h2>
			<iframe src="https://www.google.com.qa/maps/d/u/0/embed?mid=1FnoxM9FTZVM35SQ867ncVnQBt6bpcBk&ehbc=2E312F" width="300" height="200"></iframe>		</div>
		<div class="col-sm-4">
			<h2><u>Social Media</u><BR>Facebook</h2>
		<div class="fb-page" data-href="https://www.facebook.com/profile.php?id=100067551376751" data-tabs="timeline" data-width="200" data-height="200" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/profile.php?id=100067551376751" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/profile.php?id=100067551376751">Wolaita Sodo City Chief Administration</a></blockquote></div>	
		<br>	
		<div id="fb-root"></div>
			<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v20.0&appId=356868713743682" nonce="3GNSfzN0"></script>				<h2>Telegram</h2>
		
			<script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-post="sodocomunication/2" data-width="30%" data-userpic="true" data-color="F646A4"></script>
		</div>
    </div>
	<footer class="container-fluid bg-4 text-center">
  <p>All right reserved <a href="https://github.com/tarecp/tarecp">@ WSCM</a></p>
</footer>
</div>
<!-- footer end -->
</body>
</html>
<?php }else{
	header("Location: home.php");
} ?>
