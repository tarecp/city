<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home | Wolaita Sodo City Municipality</title>
	<meta name="author" content="Tarekegn">
	<link rel="stylesheet" type="text/css" href="css/mystyle.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
	<link rel="favicon icon" href="images/favicon.png">
	<script src="https://kit.fontawesome.com/7ae7324af5.js" crossorigin="anonymous"></script>

</head>
<body>
<!-- navbar start -->
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>

		<div class="navbar-header" >
			<a class="navbar-brand" href="#"><img src="Flag_of_Southern_Ethiopia.png" alt="" style="height: 40px; width: 80px; margin-top: -10px; margin-left: -10px"></a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav">
			<li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
			<li ><a href="about.php">About us</a></li>
			<li ><a href="gallery.php">Gallery</a></li>
			<li><a href="news.php">News and Articles</a></li>
			<li><a href="booking.php">E-Serivces</a></li>
			<li><a href="service.php">Serivces</a></li>
		<li><a href="contact.php">Contact us</a></li>
		</ul>
		<img src="Ethiopia_240-animated-flag-gifs (1).gif" alt="Image 1" style="width: 90px; height: 40px; margin-top: 8px;">
	        <ul class="nav navbar-nav navbar-right">
			<li><a href="one.php"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>
			<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
		</ul>
	</div>
	</div>	
	</nav>
<!-- navbar end -->

<!-- slide start -->
<div id="myCarousel" class="carousel slide" data-ride="carousel" style="margin-top: -40px">
  <!-- Indicators -->

  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
	<li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>
 
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
	<img src="Wolayta_Sodo_Tona_Roundabout.jpg" alt="municipality" style="width: 1400px; height: 580px">
	<div class="carousel-caption">
        <marquee direction="left"><h1 style="font-size: 60px; color: blue; font-weight: 900"><span >WELLCOME TO WOLAITA SODO</span></h1></marquee><br>
		<marquee direction="right"><h1 style="font-size: 60px; color: yellow; font-weight: 900"><span >CITY MUNICIPALITY</span></h1></marquee>
    </div>
    </div>
    <div class="item">
	<img src="Sodo_2.jpg" alt="municipality" style="width: 1400px; height: 580px">
    <div class="carousel-caption">
	    <marquee direction="left"><h1 style="font-size: 60px; color: red; font-weight: 900"><span >WELLCOME TO WOLAITA SODO</span></h1></marquee><br>
		<marquee direction="right"><h1 style="font-size: 60px; color: black; font-weight: 900"><span >CITY MUNICIPALITY</span></h1></marquee>

    </div>
    </div>
	<div class="item">
	<img src="Wolayta_Sodo.jpg" alt="municipality" style="width: 1400px; height: 580px">
    <div class="carousel-caption">
	  <marquee direction="up"><h1 style="font-size: 60px; color: tomato; font-weight: 900"><span >WELLCOME TO WOLAITA SODO</span></h1></marquee><br>
	  <marquee direction="up"><h1 style="font-size: 60px; color: green; font-weight: 900"><span >CITY MUNICIPALITY</span></h1></marquee>
    </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>

</div>

<!-- start end -->

<!-- welcome start -->
<div class="container-fluid text-center">
  <div class="row">
    <div class="panel panel-primary">
      <div class="panel panel-heading">
        <h2>
			<h3 style="margin-left: -900px">Population<br>
			6,142,063</h3>
			<h3 style="margin-top: -60px">Land Area<br>
			520.8/km2 (1,349/sq mi)</h3>
			<h3 style="margin-right: -900px"><p style="margin-top: -70px">No. of Woreda<br>
			16 Woreda<p></h3>
		</h2>
      </div>
    </div>
  </div>
</div>

<!-- welcome end -->

<!-- content and rightbar start-->
<div class="container-fluid">
	<div class="row">
		<div class="col-md-8">
			<div class="panel-primary" style="width: 1150px; margin-left: 30px">
				<div class="panel panel-heading">
					<h2>News</h2>
				</div>
				
				<div class="panel panel-primary">
					<div class="panel panel-heading">
					<h2>Latest News</h2>
					</div>
					<div class="panel panel-body" style="font-size: 20px">
					According to Aisha Mohammed, Minister of Urban Development and Construction of the Federal Democratic Republic of Ethiopia (FDRE), 
					Ethiopia's urbanization rate has reached 5.4 percent.

                    He said the rapid urbanization of the Southern Nations, Nationalities and People's Region (SNNPR) is unstoppable due to 
                    the migration from rural to urban areas......................
					</div>
					<center><button type="button" class="btn btn-primary btn-lg" onclick="window.open('news1.php')">Read More</button></center>
				</div>

				<div class="panel panel-primary">
					<div class="panel panel-heading">
					<h2>Yestrday News</h2>
					</div>
					<div class="panel panel-body" style="font-size: 20px">
					Deputy Chief of the Southern Nations, Nationalities and People's Region (SNNPR), Erstu Yirda, and other senior officials of 
					the state and Wolayita Zone visited an individual field in Abaya Bisare Woreda of Wolayita Zone.

                    In a short period of time, the individual has been successful in the investment sector. Investor, Dagne Daba, 
					said over 450 hectares of land has been covered with crops in one month. Mr Dagne added: He also said that he is 
					preparing to plant orange and banana seedlings. According to Dagne Masho, efforts are underway to export the produce 
					to Adingo / Boloke and Masho seeds during the harvest season.
                    He said more than 250 temporary and permanent workers have been created from the area. In less than a month, the 
					effort to cover more than 450 hectares of land with seeds is commendable and exemplary, said Deputy Chief of the 
					Southern Nations, Nationalities and People's Region, Erstu Yirda........
					</div>
					<center><button type="button" class="btn btn-primary btn-lg" onclick="window.open('news2.php')">Read More</button></center>
				</div>


				<div class="panel panel-primary">
					<div class="panel panel-heading">
					<h2>More Viewed</h2>
					</div>
					<div class="panel panel-body" style="font-size: 20px">
					Gifata is one of the festivals celebrated by the Wolayita people, and it is the celebration of the 
					New Year. In the past, at the end of the old year in Wolayita, it was known that there are wise men 
					of the lunar calendar who can analyze the movement of the moon and the stars in depth. As the festival 
					approached, the king's advisers were invited to the palace.

                    Then they go out at night and come to the four phases of the moon (Poua, Tuma, Tire and Gobana) to find 
					out the origin of the lunar cycle. Then the astrologers tell the king exactly what day of the festival 
					they are going to go home. The King then announced the approach of the festival to the people at the 
					"Chala Oduwa" (Proclamation) in the markets and public places.
					</div>
					<center><button type="button" class="btn btn-primary btn-lg" onclick="window.open('#')">Read More</button></center>
				</div>


			</div>
		</div>
	</div>
</div>
<!-- content and right bar end -->

<!-- services to book -->
<div class="container-fluid">
  <div class="text-center">
  <div class="panel panel-primary">
  <div class="panel-heading">
    <h2>Statement of Expenditure</h2>
    <h4>For developement, improvement and betterment of the municipality </h4>
    </div>
   </div>
  </div>
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary text-center">
        <div class="panel-heading">
          <h1>first three-year medieval period 
           Expenditure structure</h1>
        </div>
        <div class="panel-body" style="font-size: 20px">
		<p>Budget and program of FY 079/080 <br>
           Date: 07/12/2023</p>
          <p>A.W 079/080 Policy and Program <br>
           Date: 07/13/2022</p>
          <p>Budget and program of FY 078/079 <br>
           Date: 07/25/2021</p>
        </div>
        <div class="panel-footer">
          <button class="btn btn-danger btn-lg">other</button>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="panel panel-primary text-center">
        <div class="panel-heading">
          <h1>Planning and project</h1>
        </div>
        <div class="panel-body" style="font-size: 20px">
		<p>Wolaita Sodo municipality's first three-year medieval plan ( 2022-2024-080/081 )</p>
          <p>Periodical Development Plan of Wolaita Sodo City Municipality |
             (079/083 )</p>
          <p>Annual Village Development Plan <br>
             (20074/20075)</p>
        </div>
        <div class="panel-footer">
		<button class="btn btn-danger btn-lg">Other</button>
        </div>
      </div>
    </div>
   <div class="col-sm-4">
      <div class="panel panel-primary text-center">
        <div class="panel-heading">
          <h1>PUBLIC PROCUREMENT/BID NOTICE</h1>
        </div>
        <div class="panel-body" style="font-size: 20px">
		<p>Invitation for bids
           Date: 04/25/2024 - 8:33</p>
          <p>Invitation for bids
           Date: 01/22/2024 - 8:36</p>
          <p>Invitation for bids
           Date: 08/18/2024 - 8:13</p><br>
        </div>
        <div class="panel-footer">
		<button class="btn btn-danger btn-lg">other</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- service end -->

<!-- footer -->
<div class="container-fluid jumbotron" style="background-color: #066; color: white;">
	<div class="row">
		<div class="col-sm-4">
			<h2><u>Contact us:</u></h2>
			<h3>Wolaita Sodo City Municipality</h3>
			<p><span class="glyphicon glyphicon-map-marker"></span>Wolaita, Sodo</p>
            <p><span class="glyphicon glyphicon-phone"></span> 046-6924118</p>
           <p><span class="glyphicon glyphicon-envelope"></span> wolaitaSodoMun@gmail.com</p>
		   <div class="mann">
		        <a href="https://www.facebook.com/photo/?fbid=231803562467254&set=a.231803545800589&__tn__=%3C"><i class="fa-brands fa-facebook fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://t.me/sodocomunication"><i class="fa-brands fa-telegram fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-youtube fa-beat-fade fa-2x" style="color: #f00000;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-linkedin fa-beat-fade fa-2x" style="color: #22009e;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://sodo.gov.et/"><i class="fa-brands fa-google fa-beat-fade fa-2x" style="color: #2c0d49;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
            </div>
		</div>
		<div class="col-sm-4">
			<h2><u>Google Map</u></h2>
			<iframe src="https://www.google.com.qa/maps/d/u/0/embed?mid=1FnoxM9FTZVM35SQ867ncVnQBt6bpcBk&ehbc=2E312F" width="300" height="200"></iframe>		</div>
		<div class="col-sm-4">
			<h2><u>Social Media</u><BR>Facebook</h2>
		<div class="fb-page" data-href="https://www.facebook.com/profile.php?id=100067551376751" data-tabs="timeline" data-width="200" data-height="200" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/profile.php?id=100067551376751" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/profile.php?id=100067551376751">Wolaita Sodo City Chief Administration</a></blockquote></div>	
		<br>	
		<div id="fb-root"></div>
			<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v20.0&appId=356868713743682" nonce="3GNSfzN0"></script>				<h2>Telegram</h2>
		
			<script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-post="sodocomunication/2" data-width="30%" data-userpic="true" data-color="F646A4"></script>
		</div>
    </div>
	<footer class="container-fluid bg-4 text-center">
  <p>All right reserved <a href="https://github.com/tarecp/tarecp">@ WSCM</a></p>
</footer>
</div>
<!-- footer end -->

</body>
</html>