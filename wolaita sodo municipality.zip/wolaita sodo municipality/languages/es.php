<?php

$lang = [

	'Home'=>'Hogar',
	'About us'=>'Sobre nosotras',
	'Contact us'=>'Contacta con nosotras',
	'Login'=>'Acceso',
	'Signup'=>"Registrarse",
	'Logout'=>'Cerrar sesión',
	'Hi'=>'Hola',
	'Language'=>'Idioma',
	'Profile'=>'轮廓',
	'Settings'=>'设置',
];