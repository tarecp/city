<?php

$lang = [

	'Home'=>'Maison',
	'About us'=>'À propos de nous',
	'Contact us'=>'Contactez-nous',
	'Login'=>'Connexion',
	'Signup'=>"S'inscrire",
	'Logout'=>'Se déconnecter',
	'Hi'=>'Salut',
	'Language'=>'Langue',
	'Profile'=>'轮廓',
	'Settings'=>'设置',
];