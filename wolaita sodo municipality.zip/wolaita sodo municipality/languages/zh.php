<?php

$lang = [

	'Home'=>'家',
	'About us'=>'关于我们',
	'Contact us'=>'联系我们',
	'Login'=>'登录',
	'Signup'=>'登记',
	'Logout'=>'登出',
	'Hi'=>'你好',
	'Language'=>'语',
	'Profile'=>'轮廓',
	'Settings'=>'设置',
];