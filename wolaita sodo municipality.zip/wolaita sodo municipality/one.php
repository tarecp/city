<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Admin Signup
if(isset($_POST['admin_signup'])) {
    $admin_username = $_POST['admin_username'];
    $admin_password = $_POST['admin_password'];

    $sql = "INSERT INTO users (username, password, role) VALUES ('$admin_username', '$admin_password', 'admin')";

    if ($conn->query($sql) === TRUE) {
        echo "Admin signup successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// User Signup
if(isset($_POST['user_signup'])) {
    $user_username = $_POST['user_username'];
    $user_password = $_POST['user_password'];

    $sql = "INSERT INTO users (username, password, role) VALUES ('$user_username', '$user_password', 'user')";

    if ($conn->query($sql) === TRUE) {
        echo "User signup successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// employee signup

if(isset($_POST['employee_signup'])) {
    $user_username = $_POST['employee_username'];
    $user_password = $_POST['employee_password'];

    $sql = "INSERT INTO users (username, password, role) VALUES ('$employee_username', '$employee_password', 'employee')";

    if ($conn->query($sql) === TRUE) {
        echo "employee signup successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup Form</title>
	<link rel="stylesheet" type="text/css" href="12.css">
</head>
<body background="800px-Wolaita_Sodo.jpg" style="background-size: 100% 100%;">
    <div style="margin-left: 300px; display: flex; margin-top: 250px;">
        <a href="admin_sign.php"><button style="width: 150px; height: 70px; border-radius: 10px; background-color: brown; color: white; font-weight: 25pxt: 900; font-size: 25px">Admin</button></a>
        <a href="employee_sign.php"><button  style="width: 150px; height: 70px; border-radius: 10px; margin-left: 10px; background-color: brown; color: white; font-weight: 25pxt: 900; font-size: 25px">Employee</button></a>
        <a href="user_sign.php"><button  style="width: 150px; height: 70px; border-radius: 10px; margin-left: 10px; background-color: brown; color: white; font-weight: 25pxt: 900; font-size: 25px">User</button></a>
    </div>
</body>
</html>

<?php
$conn->close();
?>
