<?php 
   session_start();
   include "db_conn.php";
   if (isset($_SESSION['username']) && isset($_SESSION['id'])) {   ?>

<!DOCTYPE html>
<html>
<head>
	<title>Login Part</title>
	<link href="stylesheet" rel="1.css">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
      <div class="container d-flex justify-content-center align-items-center"
      style="min-height: 100vh">
      	<?php if ($_SESSION['role'] == 'admin') {?>
      		<!-- For Admin -->
      		<div class="card" style="width: 18rem;">
			  <img src="Wolayta_Sodo_Tona_Roundabout.jpg" 
			       class="card-img-top" 
			       alt="admin image">
			  <div class="card-body text-center">
			    <h5 class="card-title">
			    	<?=$_SESSION['name']?>
			    </h5>
			    <a href="logout.php" class="btn btn-dark">Logout</a>
				<a href="main.php" class="btn btn-dark">YES</a>
			  </div>
			</div>
			<div class="p-3">
				<?php include 'php/members.php';
                 if (mysqli_num_rows($res) > 0) {?>
                  
				<h1 class="display-4 fs-1">Admin Page</h1>
				
				<?php }?>
			</div>
      	<?php }
		elseif($_SESSION['role']=='user') { ?>
      		<!-- FORE USERS -->
      		<div class="card" style="width: 18rem;">
			  <h1>User Page</h1>
			  <img src="Wolayta_Sodo.jpg" 
			       class="card-img-top" 
			       alt="admin image">
			  <div class="card-body text-center">
			    <h5 class="card-title">
			    	<?=$_SESSION['name']?>
			    </h5>

			    <a href="logout.php" class="btn btn-dark">Logout</a>
				
				<a href="index.php" class="btn btn-dark">YES</a>
			  </div>
			</div>
      	<?php }else{ ?>
		<!-- for employee -->

		
		<div class="card" style="width: 18rem;">
			  <h1>Employee Page</h1>
			  <img src="Sodo_2.jpg" 
			       class="card-img-top" 
			       alt="employee image">
			  <div class="card-body text-center">
			    <h5 class="card-title">
			    	<?=$_SESSION['name']?>
			    </h5>

			    <a href="logout.php" class="btn btn-dark">Logout</a>
				
				<a href="news.php" class="btn btn-dark">YES</a>
			  </div>
			</div>
      	<?php } ?>
      </div>

	  <!-- footer -->
<div class="container-fluid jumbotron" style="background-color: #066; color: white;">
	<div class="row">
		<div class="col-sm-4">
			<h2><u>Contact us:</u></h2>
			<h3>Wolaita Sodo City Municipality</h3>
			<p><span class="glyphicon glyphicon-map-marker"></span>Wolaita, Sodo</p>
            <p><span class="glyphicon glyphicon-phone"></span> 046-6924118</p>
           <p><span class="glyphicon glyphicon-envelope"></span> wolaitaSodoMun@gmail.com</p>
		   <div class="mann">
		        <a href="https://www.facebook.com/photo/?fbid=231803562467254&set=a.231803545800589&__tn__=%3C"><i class="fa-brands fa-facebook fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://t.me/sodocomunication"><i class="fa-brands fa-telegram fa-beat-fade fa-2x" style="color: #74C0FC;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-youtube fa-beat-fade fa-2x" style="color: #f00000;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href=""><i class="fa-brands fa-linkedin fa-beat-fade fa-2x" style="color: #22009e;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
		        <a href="https://sodo.gov.et/"><i class="fa-brands fa-google fa-beat-fade fa-2x" style="color: #2c0d49;"></i></a>&nbsp&nbsp&nbsp&nbsp&nbsp
            </div>
		</div>
		<div class="col-sm-4">
			<h2><u>Google Map</u></h2>
			<iframe src="https://www.google.com.qa/maps/d/u/0/embed?mid=1FnoxM9FTZVM35SQ867ncVnQBt6bpcBk&ehbc=2E312F" width="300" height="200"></iframe>		</div>
		<div class="col-sm-4">
			<h2><u>Social Media</u><BR>Facebook</h2>
		<div class="fb-page" data-href="https://www.facebook.com/profile.php?id=100067551376751" data-tabs="timeline" data-width="200" data-height="200" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/profile.php?id=100067551376751" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/profile.php?id=100067551376751">Wolaita Sodo City Chief Administration</a></blockquote></div>	
		<br>	
		<div id="fb-root"></div>
			<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v20.0&appId=356868713743682" nonce="3GNSfzN0"></script>				<h2>Telegram</h2>
		
			<script async src="https://telegram.org/js/telegram-widget.js?22" data-telegram-post="sodocomunication/2" data-width="30%" data-userpic="true" data-color="F646A4"></script>
		</div>
    </div>
	<footer class="container-fluid bg-4 text-center">
  <p>All right reserved <a href="https://github.com/tarecp/tarecp">@ WSCM</a></p>
</footer>
</div>
<!-- footer end -->


</body>
</html>
<?php }else{
	header("Location: login.php");
} ?>