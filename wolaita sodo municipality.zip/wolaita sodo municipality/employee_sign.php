<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Admin Signup
if(isset($_POST['admin_signup'])) {
    $admin_username = $_POST['admin_username'];
    $admin_password = $_POST['admin_password'];

    $sql = "INSERT INTO users (username, password, role) VALUES ('$admin_username', '$admin_password', 'admin')";

    if ($conn->query($sql) === TRUE) {
        echo "Admin signup successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// User Signup
if(isset($_POST['user_signup'])) {
    $user_username = $_POST['user_username'];
    $user_password = $_POST['user_password'];

    $sql = "INSERT INTO users (username, password, role) VALUES ('$user_username', '$user_password', 'user')";

    if ($conn->query($sql) === TRUE) {
        echo "User signup successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


//Employee Signup
if(isset($_POST['employee_signup'])) {
    $admin_username = $_POST['employee_username'];
    $admin_password = $_POST['employee_password'];

    $sql = "INSERT INTO users (username, password, role) VALUES ('$employee_username', '$employee_password', 'employee')";

    if ($conn->query($sql) === TRUE) {
        echo "Employee signup successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employee Signup Form</title>
    <link rel="stylesheet" href="on.css">
</head>
<body background="aa.jpg" style="background-size: 100% 100%">
    <label><h2>Employee Signup</h2></label>
    <form method="post" action="">
        <label>First_Name:</label>
        <input type="text" name="user_fname" required><br><br>
        <label>Last Name:&nbsp;</label>
        <input type="text" name="user_lname" required><br><br>
        <label>Email: &nbsp&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
        <input type="email" name="user_email" required><br><br>
        <label>Username:&nbsp&nbsp;</label>
        <input type="text" name="admin_username" required><br><br>
        <label>Password:&nbsp&nbsp;</label>
        <input type="password" name="admin_password" required><br><br>
        <input class="sign" type="submit" name="admin_signup" value="Signup"><br>
        Have account?<a href="login.php"><span style="color: yellow">Login</span></a>
    </form>
</body>
</html>

<?php
$conn->close();
?>
